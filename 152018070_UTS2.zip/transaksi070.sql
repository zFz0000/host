-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2020 at 05:37 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `transaksi070`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang070`
--

CREATE TABLE `barang070` (
  `id` varchar(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `barang070`
--

INSERT INTO `barang070` (`id`, `nama`, `harga`) VALUES
('B-01', 'Baju bekas atta halilintar', 1000000),
('B-02', 'Baju polos putih', 55000),
('B-03', 'Kemeja Tanpa Kerah', 150000),
('B-04', 'Jaket Tanpa Lengan', 100000),
('B-05', 'Sweater Lengan Pendek', 75000);

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan070`
--

CREATE TABLE `pelanggan070` (
  `id` varchar(11) NOT NULL,
  `nama` char(50) NOT NULL,
  `kota` varchar(25) NOT NULL,
  `hp` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pelanggan070`
--

INSERT INTO `pelanggan070` (`id`, `nama`, `kota`, `hp`) VALUES
('P-01', 'Faraaz', 'Bandung', '081111111111'),
('P-02', 'Naruto', 'Konoha', '082222222222'),
('P-03', 'Shikamaru', 'Konoha', '083333333333'),
('P-04', 'Gaara', 'Suna', '084444444444'),
('P-05', 'Killer Bee', 'Kumo', '085555555555');

-- --------------------------------------------------------

--
-- Table structure for table `sales070`
--

CREATE TABLE `sales070` (
  `id` varchar(11) NOT NULL,
  `nama` char(50) NOT NULL,
  `kelamin` enum('p','w') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sales070`
--

INSERT INTO `sales070` (`id`, `nama`, `kelamin`) VALUES
('S-01', 'Luffy', 'p'),
('S-02', 'Sanji', 'p'),
('S-03', 'Usopp', 'p'),
('S-04', 'Tony', 'p'),
('S-05', 'Nami', 'w');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi070`
--

CREATE TABLE `transaksi070` (
  `id` int(11) NOT NULL,
  `id_sales` varchar(11) NOT NULL,
  `nama_sales` char(50) NOT NULL,
  `id_pelanggan` varchar(11) NOT NULL,
  `nama_pelanggan` char(50) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaksi070`
--

INSERT INTO `transaksi070` (`id`, `id_sales`, `nama_sales`, `id_pelanggan`, `nama_pelanggan`, `date`) VALUES
(1, 'S-01', 'Luffy', 'P-01', 'Faraaz', '2020-07-01'),
(2, 'S-02', 'Sanji', 'P-02', 'Naruto', '2020-07-02'),
(3, 'S-03', 'Usopp', 'P-03', 'Shikamaru', '2020-07-03'),
(4, 'S-04', 'Tony', 'P-04', 'Gaara', '2020-07-04'),
(5, 'S-05', 'Nami', 'P-05', 'Killer Bee', '2020-07-05');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_item070`
--

CREATE TABLE `transaksi_item070` (
  `id` int(11) NOT NULL,
  `id_barang` varchar(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaksi_item070`
--

INSERT INTO `transaksi_item070` (`id`, `id_barang`, `nama_barang`, `qty`) VALUES
(1, 'B-01', 'Baju bekas atta halilintar', 1),
(2, 'B-02', 'Baju polos putih', 160),
(3, 'B-03', 'Kemeja Tanpa Kerah', 50),
(4, 'B-04', 'Jaket Tanpa Lengan', 25),
(5, 'B-05', 'Sweater Lengan Pendek', 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang070`
--
ALTER TABLE `barang070`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `pelanggan070`
--
ALTER TABLE `pelanggan070`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales070`
--
ALTER TABLE `sales070`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaksi070`
--
ALTER TABLE `transaksi070`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_pelanggan` (`id_pelanggan`),
  ADD KEY `id_sales` (`id_sales`);

--
-- Indexes for table `transaksi_item070`
--
ALTER TABLE `transaksi_item070`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_barang` (`id_barang`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transaksi070`
--
ALTER TABLE `transaksi070`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `transaksi_item070`
--
ALTER TABLE `transaksi_item070`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transaksi070`
--
ALTER TABLE `transaksi070`
  ADD CONSTRAINT `transaksi070_ibfk_1` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan070` (`id`),
  ADD CONSTRAINT `transaksi070_ibfk_2` FOREIGN KEY (`id_sales`) REFERENCES `sales070` (`id`);

--
-- Constraints for table `transaksi_item070`
--
ALTER TABLE `transaksi_item070`
  ADD CONSTRAINT `transaksi_item070_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `barang070` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
